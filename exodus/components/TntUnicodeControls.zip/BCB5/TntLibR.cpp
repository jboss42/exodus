//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TntLibR.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("..\Unicode.pas");
USEUNIT("..\ConvertUTF7.pas");
USEUNIT("..\TntClasses.pas");
USEUNIT("..\TntComCtrls.pas");
USERES("..\TntComCtrls.dcr");
USEUNIT("..\TntControls.pas");
USEUNIT("..\TntForms.pas");
USEUNIT("..\TntGraphics.pas");
USEUNIT("..\TntMenus.pas");
USERES("..\TntMenus.dcr");
USEUNIT("..\TntStdCtrls.pas");
USERES("..\TntStdCtrls.dcr");
USEUNIT("..\TntWideStrPropHelper.pas");
USEUNIT("..\ActiveIMM_TLB.pas");
USEPACKAGE("Vclx50.bpi");
USEPACKAGE("VCLDB50.bpi");
USEUNIT("..\TntDBGrids.pas");
USEUNIT("..\TntDBCtrls.pas");
USERES("..\TntDBCtrls.dcr");
USEUNIT("..\TntDB.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
