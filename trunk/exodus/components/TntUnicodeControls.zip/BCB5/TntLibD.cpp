//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("TntLibD.res");
USEPACKAGE("vcl50.bpi");
USEUNIT("..\TntComCtrls_Design.pas");
USEUNIT("..\TntDesignEditors_Design.pas");
USEUNIT("..\TntForms_Design.pas");
USEUNIT("..\TntMenus_Design.pas");
USEFORMNS("..\TntStrEdit_Design.pas", Tntstredit_design, TntStrEditDlg);
USEUNIT("..\TntDBGrids_Design.pas");
USEUNIT("..\TntUnicodeVcl_Register.pas");
USEPACKAGE("TntLibR.bpi");
USEPACKAGE("dsnide50.bpi");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("dcldb50.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
