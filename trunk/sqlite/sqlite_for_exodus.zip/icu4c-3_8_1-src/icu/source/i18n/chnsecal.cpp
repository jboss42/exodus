/*
 ******************************************************************************
 * Copyright (C) 2003-2004, International Business Machines Corporation and   *
 * others. All Rights Reserved.                                               *
 ******************************************************************************
 *
 *
 ******************************************************************************
 */
#include "chnsecal.h"

// Placeholder for now until the implementation can be finished.

